import 'package:flutter/material.dart';

class listAttributes {


  String title;

  String price;

  String type;

  String wegiht;

  String color;

  String image;

  String merchant;

  int quantity=1;

  listAttributes(this.title, this.price, this.type, this.wegiht, this.color, this.image,
      this.merchant);

  String getTitle(String title)
  {
    title=this.title;
  }

}