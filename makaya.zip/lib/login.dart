import 'package:flutter/material.dart';
import 'main.dart';
import 'signup.dart';
import 'test.dart';
class Login extends StatefulWidget{
  static String tag="login";
  @override
  LoginState createState() => new LoginState();
}

class LoginState  extends State<Login>{
  TextEditingController emailController=new TextEditingController();
  TextEditingController passwordController=new TextEditingController();
  final formKey=GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    final logo=Hero(
      tag:'makaya',
      child:CircleAvatar(
        backgroundColor:Colors.transparent,
        radius:48.0,
        child:Image.asset('assets/images/makaya.jpg'),

      ),

    );
    final email=TextFormField(
      keyboardType:TextInputType.emailAddress,
      autofocus: false,
      controller:emailController ,
      validator:(value){
        if(value.isEmpty)
          return "Please Enter Email";
      },
      decoration:InputDecoration(
          hintText:'Email',
          contentPadding:EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0,),
          border:OutlineInputBorder(borderRadius:BorderRadius.circular(32.0) )

      ),

    );
    final password=TextFormField(
      obscureText:true,
      autofocus: false,

      controller:passwordController ,
      validator:(value){
        if(value.isEmpty)
          return "Please Enter Password";
      },
      decoration:InputDecoration(
          hintText:'Password',
          contentPadding:EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0,),
          border:OutlineInputBorder(borderRadius:BorderRadius.circular(32.0), )

      ),

    );
    final loginButton=new ButtonTheme(
      minWidth: 330.0,
      padding: new EdgeInsets.all(0.0),
      child: RaisedButton(
        child:Text("Login",style:TextStyle(color:Colors.white,fontSize: 20.0),),
        color:Colors.blueGrey[700],


        onPressed:()
        {
          Navigator.push(context,MaterialPageRoute(builder: (context) => GridLayout()));

        },
      ),
    );

    final signUpLink=FlatButton(
      child:Text("Not a Member? Sign Up",
        style:TextStyle(color:Colors.blueGrey[900],fontSize: 15.0),),
      onPressed: ()
      {
        Navigator.push(context,MaterialPageRoute(builder: (context) => SignUp()));

      },

    );
    return Scaffold(
      backgroundColor:Colors.white,

      body:Form(key:formKey,
        child:Column(
          mainAxisAlignment:MainAxisAlignment.center,
          children: <Widget>[
            SizedBox(height:30.0),
            logo,
            SizedBox(height:30.0),
            email,
            SizedBox(height:20.0),
            password,
            SizedBox(height:20.0),
            loginButton,
            signUpLink,

          ],
        ),
      ),
    );

  }

}