import 'package:flutter/material.dart';
import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';
import 'webview.dart';
class List extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'My App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Scaffold(
        appBar: AppBar(title: Text('Makaya')),
        body: BodyWidget(),
      ),
    );
  }
}
String amazonUrl = 'https://images-na.ssl-images-amazon.com/images/G/01/gc/designs/livepreview/amazon_dkblue_noto_email_v2016_us-main._CB468775337_.png';
String ebayUrl = 'https://images-na.ssl-images-amazon.com/images/I/41xNWzvMucL._SY355_.png';
String olxUrl = 'https://images-na.ssl-images-amazon.com/images/I/41xNWzvMucL._SY355_.png';
String aliExpressUrl = 'https://images-na.ssl-images-amazon.com/images/I/41xNWzvMucL._SY355_.png';
String etsyUrl = 'https://images-na.ssl-images-amazon.com/images/I/41xNWzvMucL._SY355_.png';

class BodyWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
     return Scaffold(
       body: ListView(
        children: <Widget>[
          ListTile(
            leading: CircleAvatar(
              backgroundImage: NetworkImage(amazonUrl),
            ),
            title: Text('Amazon'),
            subtitle: Text('Shop Here'),
            trailing: Icon(Icons.keyboard_arrow_right),
            onTap: () {


              Navigator.push(context,MaterialPageRoute(builder: (context) => WebViewAmazon()));


            },
            selected: true,
          ),
          ListTile(
            leading: CircleAvatar(
              backgroundImage: NetworkImage(ebayUrl),
            ),
            title: Text('Ebay'),
            subtitle: Text('Shop Here'),
            trailing: Icon(Icons.keyboard_arrow_right),
            onTap: () {
              print('cow');
            },
          ),
          ListTile(
            leading: CircleAvatar(
              backgroundImage: NetworkImage(olxUrl),
            ),
            title: Text('Camel'),
            subtitle: Text('Comes with humps'),
            trailing: Icon(Icons.keyboard_arrow_right),
            onTap: () {
              print('camel');
            },
            enabled: false,
          ),
          ListTile(
            leading: CircleAvatar(
              backgroundImage: NetworkImage(aliExpressUrl),
            ),
            title: Text('Sheep'),
            subtitle: Text('Provides wool'),
            trailing: Icon(Icons.keyboard_arrow_right),
            onTap: () {
              print('sheep');
            },
          ),
          ListTile(
            leading: CircleAvatar(
              backgroundImage: NetworkImage(etsyUrl),
            ),
            title: Text('Goat'),
            subtitle: Text('Some have horns'),
            trailing: Icon(Icons.keyboard_arrow_right),
            onTap: () {
              print('goat');
            },
          ),
        ],
    ),
     );
     
  }
}