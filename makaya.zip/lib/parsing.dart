import 'package:flutter/material.dart';
import 'listAttributes.dart';
import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'dart:core';
import 'package:html/parser.dart' show parse;
import 'package:html/dom.dart';
class AmazonDataParsing
{

static List<listAttributes> aitems = new List();
FlutterWebviewPlugin fwvp = new FlutterWebviewPlugin();

  void viewProduct(String url)  async
  {
    var menu=null;
    try {
      menu = await http.get(url);
      print('see url');
      print(url);
      print('see url');




    //String s = ;

    var document = parse(menu.body);

    var getCatogory = document.getElementsByClassName("a-link-normal a-color-tertiary");

    print(getCatogory[0].text);

    String check = getCatogory[0].text;

    check = check.trim();

    if(check == "Books")
        parsingbooks(document);
    if(check != "Books"){

      parsingCellPhones(document,check);

    }
    if(check == "Clothing, Shoes & Jewelry"){


      print("Clothing, Shoes & Jewelry ::>  ");

    }

    }
    catch(e)
    {
      print("chutya");
      print(e);

      return ;
    }
    //return menu.body;

  }
  void parsingbooks(Document document){

    var imageTag = document.getElementById("imgBlkFront");

    var src = imageTag.attributes;

    String image = src["data-a-dynamic-image"];

    image = image.substring(image.indexOf("\"",0)+1,image.indexOf("\"",image.indexOf("\"",0)+1));

    //get price
    var priceTag = document.getElementsByClassName("a-color-price");
    print(priceTag.elementAt(1).text);

    //get color types : class swatchSelect

    //get a-size-base

    //get id productTitle

    //get other information id="prodDetails"





    print('see data');

  }

  void parsingCellPhones(Document document,String type){


    //get image

    var imageTag = document.getElementById("landingImage");

    var src = imageTag.attributes;

    String image = src["data-a-dynamic-image"];

    image = image.substring(image.indexOf("\"",0)+1,image.indexOf("\"",image.indexOf("\"",0)+1));

    //get Price

    var priceTag = document.getElementsByClassName("a-color-price");
    print(priceTag[0].text);

    String price = priceTag[0].text.trim();
    //get title

    var titleTag = document.getElementById("productTitle");

    print(titleTag.text.trim());

    String title = titleTag.text.trim();

    //get Weight


    var weightTag = document.getElementsByClassName("a-size-base");

    int weightIndex=0;

    String checkweightclass = "";
    String checkweightindex = "";
    for(int i=0;i<weightTag.length;i++){

      checkweightclass =weightTag[i].attributes["class"].trim();
      if(checkweightclass != null)

        if(checkweightclass == "a-color-secondary a-size-base prodDetSectionEntry")
        {

          checkweightindex = weightTag[i].text.trim();
          if(checkweightindex == "Item Weight") {
            weightIndex = i + 1;
            break;
          }
        }
    }


    String weight = weightTag[weightIndex].text.trim();

    int flag=0;
    if(!weight.contains("ounces"))
        weight="";
    for(int i=0;i<aitems.length;i++)
      if(image  == aitems[i].image){
        aitems[i].quantity++;
        flag=1;
        fwvp.evalJavascript("alert('item updated')");
        break;
      }

  if(flag==0) {
    aitems.add(new listAttributes(
        title,
        price,
        type,
        weight,
        "",
        image,
        "Amazon"));
    print("see data");
    //fwvp.evalJavascript("jQuery('#preloader').remove();");
    fwvp.evalJavascript("alert('item added')");
  }

  }






}