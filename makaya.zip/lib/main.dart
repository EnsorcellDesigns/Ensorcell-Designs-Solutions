import 'package:flutter/material.dart';
import 'login.dart';
import 'webviewtest.dart';
import 'test.dart';

void main() => runApp(
    MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
        ),
        home: GridLayout())
);
class MyApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return MaterialApp(
        title: 'Makaya',
        theme: ThemeData(

        ),
        home:Scaffold(
          appBar:AppBar(
            title:Text(
              'Makaya',
              style: TextStyle(color:Colors.white ),
            ) ,
          ) ,
        )
    );
  }

}


