import 'package:flutter/material.dart';
import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'parsing.dart';
import 'ViewCart.dart';
import 'test.dart';
import 'package:liquid_progress_indicator/liquid_progress_indicator.dart';
import 'package:badges/badges.dart';
class WebViewAmazon extends StatefulWidget{
  @override
  WebViewAmazonState createState() {

    return new WebViewAmazonState();
  }
}

class WebViewAmazonState extends State<WebViewAmazon> {
  AmazonDataParsing obj = new AmazonDataParsing();
  int _incrementTab() {
    int count=0;
    setState(() {
      count=AmazonDataParsing.aitems.length;
      return count;
    });

  }
  @override
  Widget build(BuildContext context) {
    FlutterWebviewPlugin fwvp = new FlutterWebviewPlugin();
    return WebviewScaffold(

      url: 'https://www.amazon.com',
      hidden: true,
      appBar:AppBar(
        iconTheme: new IconThemeData(color: Colors.white),

        backgroundColor:new Color(0XFF2B567E),

        title:Text(
          'Makaya',
          style: TextStyle(color:Colors.white ),
        ) ,
        actions: <Widget>[
          Badge(
            animationType: BadgeAnimationType.slide,
            position: BadgePosition(top: 0,right: 0),
            badgeContent: Text(AmazonDataParsing.aitems.length.toString()),
            child: new IconButton(icon: new Icon(Icons.shopping_cart,color: Colors.white,), onPressed: (){
              Navigator.push(context,MaterialPageRoute(builder: (context) => ViewCartItems()));
              fwvp.hide();
            }),

          ),


        ],
      ) ,

//
  //    withJavascript: true,




      bottomNavigationBar:BottomNavigationBar(


        type: BottomNavigationBarType.shifting ,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.shopping_cart,color: Color.fromARGB(255, 0, 0, 0)),
            title: new Text("Add to Cart",style: TextStyle(color: Colors.red),),

          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.arrow_back,color: Color.fromARGB(255, 0, 0, 0)),

            title: new Text("back",style: TextStyle(color: Colors.blueAccent),),


          ),
        ],
        onTap: (index){
          if(index == 0){



            fwvp.onUrlChanged.listen((String urll){

         //     String url =  urll;
              print(urll);
              obj.viewProduct(urll);
         //     Navigator.pop(context);




            });



          }
          else
            {
              Navigator.push(context,MaterialPageRoute(builder: (context) => GridLayout()));

            }
        },
      ),






    );










  }
}