import 'package:flutter/material.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import 'checkout.dart';
import 'listAttributes.dart';
import 'parsing.dart';
import 'webview.dart';
class ViewCartItems extends StatefulWidget {
  @override
  ViewCart createState() => new ViewCart();
}

class ViewCart extends State<ViewCartItems> {
  static listAttributes obj;



    
    

  
  
 void add(index) {

   setState(() {
                  AmazonDataParsing.aitems[index].quantity++;
   });

 }
       void minus(index)
       {
         setState(()
         {
           if (AmazonDataParsing.aitems[index].quantity != 1) {
             AmazonDataParsing.aitems[index].quantity--;
           }
         });
       }
       void remove(index)
       {
             setState(()
             {
                      AmazonDataParsing.aitems.removeAt(index);
             });
       }

  Widget _buildProductItem(BuildContext context, int index) {



    return Card(
      child: Column(
        children: <Widget>[
          Image.network(AmazonDataParsing.aitems[index].image,width: 80,height: 120,alignment: Alignment.center,),
          Text(AmazonDataParsing.aitems[index].title, style: TextStyle(color: Colors.blueAccent,fontWeight:FontWeight.bold),),
          Text(AmazonDataParsing.aitems[index].wegiht, style: TextStyle(color: Colors.blueAccent)),
          Text(AmazonDataParsing.aitems[index].price, style: TextStyle(color: Colors.red,fontWeight:FontWeight.bold)),
          Text(AmazonDataParsing.aitems[index].type, style: TextStyle(color: Colors.blueAccent)),
          Text(AmazonDataParsing.aitems[index].merchant, style: TextStyle(color: Colors.blueAccent)),
          new ButtonTheme(
            minWidth: 100.0,
            padding: new EdgeInsets.all(0.0),
            child: RaisedButton(
              child: new Icon(Icons.add,color:Colors.white),
              color: Colors.blueAccent,
              onPressed: (){

                add(index);

              },
            ),
          ) ,
             new Text(AmazonDataParsing.aitems[index].quantity.toString(), style: new TextStyle(fontSize: 40.0)),
          new ButtonTheme(
               minWidth:100.0 ,
                   padding:new EdgeInsets.all(0.0),
                   child: RaisedButton(
                    child: new Icon(const IconData(0xe15b, fontFamily: 'MaterialIcons'),color:Colors.white),
                     color: Colors.blueAccent,
                     onPressed: (){minus(index);},

                   ),

             ),


      new ButtonTheme(
      minWidth: 330.0,
      padding: new EdgeInsets.all(0.0),
      child: RaisedButton(
        child:Text("Delete",style:TextStyle(color:Colors.white,fontSize: 20.0),),
        color:Colors.red[700],


        onPressed:()
        {
          Alert(
            context: context,
            type: AlertType.warning,
            title: "Remove Item",
            desc: "Are you you want to remove item from cart?",
            buttons: [
              DialogButton(
                child: Text(
                  "Yes",
                  style: TextStyle(color: Colors.white, fontSize: 20),
                ),
                onPressed: () {
                  remove(index);
                  Navigator.pop(context);

                },

                color: Color.fromRGBO(0, 179, 134, 1.0),
              ),
              DialogButton(
                child: Text(
                  "No",
                  style: TextStyle(color: Colors.white, fontSize: 20),
                ),
                onPressed: () => Navigator.pop(context),
                gradient: LinearGradient(colors: [
                  Color.fromRGBO(116, 116, 191, 1.0),
                  Color.fromRGBO(52, 138, 199, 1.0)
                ]),
              )
            ],
          ).show();
        },
      ),
    ),


     ],


      ),

    );



  }


  @override
  Widget build(BuildContext context) {

   //removeSimilar();

    final checkOutButton=new ButtonTheme(
      minWidth: 330.0,
      padding: new EdgeInsets.all(0.0),
      child: RaisedButton(
        child:Text("Checkout",style:TextStyle(color:Colors.white,fontSize: 20.0),),
        color:Colors.blueGrey[700],


        onPressed:()
        {
          Navigator.push(context,MaterialPageRoute(builder: (context) => CheckOut()));

        },
      ),
    );
    final totalAmount=Text(
        'Total Amount=2800',
        style: TextStyle(
            color: Colors.grey[800],
            fontWeight: FontWeight.bold,
            fontSize: 20));
    final totalItems=Text(
        'Total Items='+AmazonDataParsing.aitems.length.toString(),
        style: TextStyle(
            color: Colors.grey[800],
            fontWeight: FontWeight.bold,
            fontSize: 20));

    if(AmazonDataParsing.aitems.length==0)
      {

         return Scaffold(

           body:new Column(
             mainAxisAlignment:MainAxisAlignment.center,
               children: <Widget>[
            new ButtonTheme(
             minWidth: 400.0,
             padding: new EdgeInsets.all(0.0),
             child:  FlatButton(
           child:Text("No Items at Cart.Want to add items at cart?",
             style:TextStyle(color:Colors.blueGrey[900],fontSize: 15.0),),
           onPressed: ()
           {
             Navigator.push(context,MaterialPageRoute(builder: (context) => WebViewAmazon()));

           },

             ),
           )
           ]


           ) ,



         );



      }
      else {
      return Scaffold(
        appBar: AppBar(
          iconTheme: new IconThemeData(color: Colors.white),

          backgroundColor: new Color(0XFF2B567E),

          title: Text(
            'Makaya',
            style: TextStyle(color: Colors.white),
          ),
        ),
        backgroundColor: Colors.white,


        body:Container(
          child: Column(
              mainAxisAlignment:MainAxisAlignment.end,
              children: <Widget>[

                SizedBox(height:20.0),
                totalItems,
                SizedBox(height:10.0),
                checkOutButton,



        Expanded(
           child: ListView.builder(
            itemBuilder: _buildProductItem,
            itemCount: AmazonDataParsing.aitems.length,
          ),

        ),
      ])
        ),
        floatingActionButton:FloatingActionButton.extended(
          onPressed: () {
            Navigator.push(context,MaterialPageRoute(builder: (context) => WebViewAmazon()));
          },
          icon: Icon(Icons.add_shopping_cart),
          label: Text("Shop More"),
          backgroundColor: Colors.deepOrange,
        ),






      );
    }





  }

}
