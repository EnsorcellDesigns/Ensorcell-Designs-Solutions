import 'package:flutter/material.dart';
import 'main.dart';
import 'test.dart';
import 'package:fluttertoast/fluttertoast.dart';
class SignUp extends StatefulWidget
{
  static String tag="signup";
  @override
  SignUpState createState( )=> new SignUpState();

}
class SignUpState extends State<SignUp>
{
  TextEditingController nameController=new TextEditingController();
  TextEditingController emailController=new TextEditingController();
  TextEditingController passwordController=new TextEditingController();
  TextEditingController phoneController=new TextEditingController();
  final formKey=GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    final logo=Hero(
      tag:'tanawul',
      child:CircleAvatar(
        backgroundColor:Colors.transparent,
        radius:48.0,
        child:Image.asset('assets/images/makaya.jpg'),

      ),

    );
    final name=TextFormField(
      keyboardType:TextInputType.text,
      autofocus: false,
      controller:nameController,
      validator:(value){
        if(value.isEmpty)
          return "Please Enter Name";
      },
      decoration:InputDecoration(

          hintText:'NAME',
          contentPadding:EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0,),
          border:OutlineInputBorder(borderRadius:BorderRadius.circular(32.0) )

      ),

    );
    final email=TextFormField(
      keyboardType:TextInputType.emailAddress,
      autofocus: false,

      controller:emailController ,
      validator:(value){
        if(value.isEmpty)
          return "Please Enter Email";
      },
      decoration:InputDecoration(
          hintText:'EMAIL',
          contentPadding:EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0,),
          border:OutlineInputBorder(borderRadius:BorderRadius.circular(32.0) )

      ),

    );
    final phone=TextFormField(
      keyboardType:TextInputType.phone,
      autofocus: false,
      controller:phoneController ,
      validator:(value){
        if(value.isEmpty)
          return "Please Enter Phone Number";
      },
      decoration:InputDecoration(
          hintText:'PHONE NUMBER',

          contentPadding:EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0,),
          border:OutlineInputBorder(borderRadius:BorderRadius.circular(32.0) )

      ),

    );
    final password=TextFormField(
      obscureText:true,
      autofocus: false,
      controller:passwordController,
      validator:(value){
        if(value.isEmpty)
          return "Please Enter Password";
      },
      decoration:InputDecoration(
          hintText:'PASSWORD',
          contentPadding:EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0,),
          border:OutlineInputBorder(borderRadius:BorderRadius.circular(32.0), )


      ),

    );
    final signUpButton=new ButtonTheme(
      minWidth: 330.0,
      padding: new EdgeInsets.all(0.0),
      child: RaisedButton(
        child:Text("Sign Up",style:TextStyle(color:Colors.white,fontSize: 20.0),),
        color:Colors.blueGrey[700],


        onPressed:()
        {
          Navigator.push(context,MaterialPageRoute(builder: (context) => GridLayout()));

        },
      ),
    );

    return Scaffold(
      backgroundColor:Colors.white,
      body:Form(key:formKey,
        child:Column(
          mainAxisAlignment:MainAxisAlignment.center,
          children: <Widget>[
            logo,
            SizedBox(height:30.0),
            name,
            SizedBox(height:20.0),
            email,
            SizedBox(height:20.0),
            phone,
            SizedBox(height:20.0),
            password,
            SizedBox(height:20.0),
            signUpButton,


          ],
        ),
      ),
    );
  }

}