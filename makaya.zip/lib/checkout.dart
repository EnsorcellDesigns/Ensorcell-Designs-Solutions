import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'listAttributes.dart';
import 'ViewCart.dart';
import 'parsing.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import 'ViewCart.dart';
class CheckOut extends StatefulWidget
{
  CheckOutItems createState() => new CheckOutItems();
}
class CheckOutItems extends State<CheckOut> {
  FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin=new FlutterLocalNotificationsPlugin();
  var initializationSettingsAndroid;
  var initializationSettingsIOS;
  var initializationSettings;

  void _showNotification() async {
    await _demoNotification();
  }
  Future<void> _demoNotification() async {
    var androidPlatformChannelSpecifics = AndroidNotificationDetails(
        'channel_ID', 'channel name', 'channel description',
        importance: Importance.Max,
        priority: Priority.High,
        ticker: 'test ticker');

    var iOSChannelSpecifics = IOSNotificationDetails();
    var platformChannelSpecifics = NotificationDetails(
        androidPlatformChannelSpecifics, iOSChannelSpecifics);

    await flutterLocalNotificationsPlugin.show(0, 'Hello, buddy',
        'We have recieved your order.ThankYou for using Makaya', platformChannelSpecifics,
        payload: 'test oayload');
  }
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    initializationSettingsAndroid =
    new AndroidInitializationSettings('makaya');
    initializationSettingsIOS = new IOSInitializationSettings(
        onDidReceiveLocalNotification: onDidReceiveLocalNotification);
    initializationSettings = new InitializationSettings(
        initializationSettingsAndroid, initializationSettingsIOS);
    flutterLocalNotificationsPlugin.initialize(initializationSettings,
        onSelectNotification: onSelectNotification);
  }
  Future onSelectNotification(String payload) async {
    if (payload != null) {
      debugPrint('Notification payload: $payload');
    }
    await Navigator.push(context,
        new MaterialPageRoute(builder: (context) => new ViewCartItems()));
  }

  Future onDidReceiveLocalNotification(
      int id, String title, String body, String payload) async {
    await showDialog(
        context: context,
        builder: (BuildContext context) => CupertinoAlertDialog(
          title: Text(title),
          content: Text(body),
          actions: <Widget>[
            CupertinoDialogAction(
              isDefaultAction: true,
              child: Text('Ok'),
              onPressed: () async {
                Navigator.of(context, rootNavigator: true).pop();
                await Navigator.push(context,
                    MaterialPageRoute(builder: (context) => ViewCartItems()));
              },
            )
          ],
        ));
  }


  double calculateTotal(){

    double total=0.0;
    String str="";

    for(int i=0;i<AmazonDataParsing.aitems.length;i++){

      str = AmazonDataParsing.aitems[i].price;
      total += (double.parse(str.substring(1))) * AmazonDataParsing.aitems[i].quantity ;
//      print(double.parse(str.substring(1)));
    }

    return total;


  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build

    final totalAmount = Text(
        'Total Amount='+calculateTotal().roundToDouble().toString(),
        style: TextStyle(
            color: Colors.grey[800],
            fontWeight: FontWeight.bold,
            fontSize: 20));
    final shippingamount = Text(
        'Shippment Amount= 500',
        style: TextStyle(
            color: Colors.grey[800],
            fontWeight: FontWeight.bold,
            fontSize: 20));
    final orderButton = new ButtonTheme(
      minWidth: 330.0,
      padding: new EdgeInsets.all(0.0),
      child: RaisedButton(
        child: Text("Confirm Order",
          style: TextStyle(color: Colors.white, fontSize: 20.0),),
        color: Colors.blueGrey[700],


        onPressed: () {
          Alert(
            context: context,
            type: AlertType.success,
            title: "Confirm Order",
            buttons: [
              DialogButton(
                child: Text(
                  "YES",
                  style: TextStyle(color: Colors.white, fontSize: 20),
                ),
                onPressed: () {
                  _showNotification();
                  AmazonDataParsing.aitems.clear();
                  Navigator.pop(context);
                },
                color: Color.fromRGBO(0, 179, 134, 1.0),
              ),
              DialogButton(
                child: Text(
                  "NO",
                  style: TextStyle(color: Colors.white, fontSize: 20),
                ),
                onPressed: () => Navigator.pop(context),
                gradient: LinearGradient(colors: [
                  Color.fromRGBO(116, 116, 191, 1.0),
                  Color.fromRGBO(52, 138, 199, 1.0)
                ]),
              )
            ],
          ).show();
        },
      ),
    );


    return Scaffold(
      appBar: AppBar(
        iconTheme: new IconThemeData(color: Colors.white),

        backgroundColor: new Color(0XFF2B567E),

        title: Text(
          'Makaya',
          style: TextStyle(color: Colors.white),
        ),
      ),

      body: Column(

        children: [
          Container(
            child: DataTable(

              columns: <DataColumn>[


                DataColumn(

                  label: Text('Title', style: TextStyle(color: Colors.black87,
                      fontSize: 12.0,
                      fontWeight: FontWeight.bold)),
                ),
                DataColumn(
                  label: Text('Quantity', style: TextStyle(color: Colors.black87,
                      fontSize: 12.0,
                      fontWeight: FontWeight.bold)),
                ),
                DataColumn(
                  label: Text('Price', style: TextStyle(color: Colors.black87,
                      fontSize: 12.0,
                      fontWeight: FontWeight.bold)),

                ),


              ],
              rows: AmazonDataParsing.aitems
                  .map(
                    (itemRow) =>
                    DataRow(
                      cells: [

                        DataCell(
                          Text(itemRow.title),


                        ),
                        DataCell(
                          Text(itemRow.quantity.toString()),
                        ),
                        DataCell(
                          Text(itemRow.price.toString()),),
                      ],
                    ),
              )
                  .toList(),
            ),

          ),
          Expanded(

            child: Align(
              alignment: FractionalOffset.bottomCenter,
              child: Container(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: <Widget>[
                    SizedBox(height: 20.0),
                    totalAmount,
                    SizedBox(height: 20.0),
                    shippingamount,
                    SizedBox(height: 10.0),
                    orderButton,
                  ],

                ),
              ),
            ),
          ),
        ],
      ),


    );
  }


}