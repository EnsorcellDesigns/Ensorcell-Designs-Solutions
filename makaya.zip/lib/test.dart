import 'package:badges/badges.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'ViewCart.dart';
import 'parsing.dart';
import 'webview.dart';
import 'login.dart';
import 'webviewebay.dart';

class GridLayout extends StatefulWidget
{
  GridLayout({ Key key }) : super(key: key);
  @override
  Stores createState() => new Stores();
}

class Stores extends State<GridLayout>

{
  List <String> events=[
    "Amazon",
    "OLX",
    "Etsy",
    "Ebay"

  ];
  List<String> _newData = [];

  _onChanged(String value) {
    setState(() {
      _newData = events
          .where((string) => string.toLowerCase().contains(value.toLowerCase()))
          .toList();
    });
  }



  TextEditingController editingController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar:AppBar(
          iconTheme: new IconThemeData(color: Colors.white),
        backgroundColor:new Color(0XFF2B567E),

        title:Text(
          'Makaya',
          style: TextStyle(color:Colors.white ),
        ) ,

      actions: <Widget>[
          Badge(
            animationType: BadgeAnimationType.slide,
            position: BadgePosition(top: 0,right: 0),
            badgeContent: Text(AmazonDataParsing.aitems.length.toString()),
            child: new IconButton(icon: new Icon(Icons.shopping_cart,color: Colors.white,), onPressed: (){
              Navigator.push(context,MaterialPageRoute(builder: (context) => ViewCartItems()));
            }),

          ),
        ],
      ) ,

      drawer: Drawer(


        child: ListView(

          // Important: Remove any padding from the ListView.
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              child: Text(''),
              decoration: BoxDecoration(

                  image: DecorationImage(
                    image: ExactAssetImage('assets/images/makayadrawer.jpg'),

                  ),

              ),
            ),
            ListTile(
              title: Text('Cart'),
              leading: new Icon(Icons.shopping_cart),

              onTap: () {
                Navigator.push(context,MaterialPageRoute(builder: (context) => ViewCartItems()));



              },
            ),
            ListTile(

              title: new Text('Stores'),
              leading: new Icon(Icons.store),

              onTap: () {

                Navigator.pop(context);
              },
            ),
            ListTile(

              title: new Text('Save'),
              leading: new Icon(Icons.save_alt),

              onTap: () {

                Navigator.pop(context);
              },
            ),
            ListTile(

              title: new Text('Feedback'),
              leading: new Icon(Icons.feedback),

              onTap: () {

                Navigator.pop(context);
              },
            ),
            ListTile(

              title: new Text('Account'),
              leading: new Icon(Icons.person),

              onTap: () {

                Navigator.pop(context);
              },
            ),
            ListTile(

              title: new Text('Logout'),
              leading: new Icon(Icons.power_settings_new),

              onTap: () {

                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
      bottomNavigationBar:BottomNavigationBar(


        type: BottomNavigationBarType.shifting ,

        items: [
          BottomNavigationBarItem(
              icon: new Icon(FontAwesomeIcons.book,color: Colors.red),
              title: new Text('Stores',style: TextStyle(color: Colors.blue))
          ),
          BottomNavigationBarItem(
              icon: Icon(Icons.person,color: Colors.red),
              title: new Text('Account',style: TextStyle(color: Colors.blue))
          ),
          BottomNavigationBarItem(
              icon: Icon(Icons.feedback,color: Colors.red),
              title: new Text('Feedback',style: TextStyle(color: Colors.blue),)
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.save_alt,color:Colors.red),
            title: new Text('Save',style: TextStyle(color: Colors.blue)),

          )
        ],
        onTap: (index){
            if(index==0)
            {
              Navigator.push(context,MaterialPageRoute(builder: (context) => ViewCartItems()));


            }
        },
      ),



      body:Container(
    child: Column(
    children: <Widget>[
    Padding(
    padding: const EdgeInsets.all(8.0),
    child: TextField(
      onChanged: _onChanged,
    controller:editingController,
    decoration: InputDecoration(
    labelText: "Search",
    hintText: "Search",
    prefixIcon: Icon(Icons.search),
    border: OutlineInputBorder(
    borderRadius: BorderRadius.all(Radius.circular(12.0)))),
    ),
    ),
    SizedBox(height: 5.0),
    _newData != null && _newData.length != 0
        ? Expanded(
      child: GridView(
          physics: BouncingScrollPhysics(),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
          children: _newData.map((title)
          {
            return GestureDetector(
              child: Card(margin:const EdgeInsets.all(20.0),
                child: getCardByTitle(title),),
              onTap: ()
              {
                if(title=="Amazon")
                  Navigator.push(context,MaterialPageRoute(builder: (context) => WebViewAmazon()));

                if(title=="Amazon")
                  Navigator.push(context,MaterialPageRoute(builder: (context) => WebViewAmazon()));

                if(title=="Amazon")
                  Navigator.push(context,MaterialPageRoute(builder: (context) => WebViewAmazon()));

                if(title=="Amazon")
                  Navigator.push(context,MaterialPageRoute(builder: (context) => WebViewAmazon()));

                if(title=="Amazon")
                  Navigator.push(context,MaterialPageRoute(builder: (context) => WebViewAmazon()));

                if(title=="Amazon")
                  Navigator.push(context,MaterialPageRoute(builder: (context) => WebViewAmazon()));






              },);

          }).toList()

      ),

    )
        : SizedBox(),

    Expanded(
      child: GridView(
          physics: BouncingScrollPhysics(),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
          children: events.map((title)
          {
            return GestureDetector(
              child: Card(margin:const EdgeInsets.all(20.0),
                child: getCardByTitle(title),),
              onTap: ()
              {
                if(title=="Amazon")
                  Navigator.push(context,MaterialPageRoute(builder: (context) => WebViewAmazon()));

                if(title=="Amazon")
                  Navigator.push(context,MaterialPageRoute(builder: (context) => WebViewAmazon()));

                if(title=="Amazon")
                  Navigator.push(context,MaterialPageRoute(builder: (context) => WebViewAmazon()));

                if(title=="Amazon")
                  Navigator.push(context,MaterialPageRoute(builder: (context) => WebViewAmazon()));

                if(title=="Amazon")
                  Navigator.push(context,MaterialPageRoute(builder: (context) => WebViewAmazon()));

                if(title=="Amazon")
                  Navigator.push(context,MaterialPageRoute(builder: (context) => WebViewAmazon()));






              },);

          }).toList()

      ),


    ),
    ],
    ),
    ),

    );

  }

  Column getCardByTitle(String title) {
    String img="";
    if(title=="Amazon")
      img = "assets/images/image2.png";
    else if(title=="Daraz")
      img = "assets/images/image1.png";
    else if(title=="Olx")
      img = "assets/images/image0.png";
    else if(title=="DSW")
      img = "assets/images/image2.png";
    else if(title=="Etsy")
      img = "assets/images/image4.png";
    else if(title=="Ebay")
      img = "assets/images/image3.png";
    else
      img = "assets/images/image2.png";
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        new Center(
          child: Container(
            child: new Stack(
              children: <Widget>[
                new Image.asset(
                  img,
                  width: 80.0,
                  height: 80.0,
                )
              ],
            ),

          ),
        ),
        Text(
          title,
          style: TextStyle(fontSize: 20.0,fontWeight: FontWeight.bold),
          textAlign: TextAlign.center,
        )
      ],
    );

  }




}