import 'package:flutter/material.dart';
import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';
class WebViewEbay extends StatelessWidget {
  String msg = 'Add To Cart';
  @override
  Widget build(BuildContext context) {
    return WebviewScaffold(
      url: 'https://www.ebay.com',
      hidden: true,
      appBar: AppBar(title: Text("Makaya")),



    );
  }
}